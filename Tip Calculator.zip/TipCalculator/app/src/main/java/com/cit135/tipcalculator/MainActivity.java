package com.cit135.tipcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.SeekBar;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    /*
    TODO Plan
    user enters the bill
    as user moves seek bar the tip % is displayed
    when user clicks button tip and total are displayed
     */
    private double billAmount = 10.00;//bill amount entered by user
    private double percent = 15;//starting tip percentage
    private double billTotal = 10.0;
    private double tipAmount = 10.00;
    private EditText bill_editTxtView;//window that displays bill amount
    private TextView percent_txtView;//displays tip percentage
    private TextView tip_txtView;//displays calculated tip
    private TextView total_txView;//displays calculated total bill amount
    private Button btn_calculate_tip;//button that tells app to do the math

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //linking xml views to java objects
        percent_txtView = (TextView) findViewById(R.id.percentTextView);
        tip_txtView = (TextView) findViewById(R.id.txtView_tip_amount);
        total_txView = (TextView) findViewById(R.id.txtView_total);
        bill_editTxtView = (EditText) findViewById(R.id.editText_bill);

        final StringBuilder stringBuilder = new StringBuilder();

        //////////////////////////////////////
        //seek bar
        SeekBar.OnSeekBarChangeListener seekBarListener = new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                percent = progress;
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        };

        SeekBar seekBar_tip_percentage = (SeekBar) findViewById(R.id.seekBar_tip_percentage);
        seekBar_tip_percentage.setOnSeekBarChangeListener(seekBarListener);
        percent_txtView.setText(stringBuilder.append(percent).toString());



        /////////////////////////////////////////

        //button click magic
        btn_calculate_tip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


               //calculations
                billAmount = Double.parseDouble(bill_editTxtView.toString());

                tipAmount = billAmount * (percent / 100);

                billTotal = billAmount + tipAmount;

                //display results
                tip_txtView.setText(stringBuilder.append(percent).toString());
                total_txView.setText(stringBuilder.append(billTotal).toString());
            }
        });





    }
}
